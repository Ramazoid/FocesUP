# Unity UI Blur Shader

This is a simple box blur shader for use with UI elements in Unity.

Instructions can be found in `Assets/UIBlur/ReadMe.txt`